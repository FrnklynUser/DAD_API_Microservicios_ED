package com.criv.fact.servicegateway2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servicegateway2Application {

	public static void main(String[] args) {
		SpringApplication.run(Servicegateway2Application.class, args);
	}

}
