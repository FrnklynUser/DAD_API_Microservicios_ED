package com.criv.fact.servicedenuncia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicedenunciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicedenunciaApplication.class, args);
	}

}
