package com.criv.fact.servicedenuncia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicedenunciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
